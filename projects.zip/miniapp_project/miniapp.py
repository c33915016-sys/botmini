"""
Codebox Mini App for the OTP bot.

Serves a Telegram Mini App (dark UI: phone search + live OTP feed) from a tiny
built-in web server. Uses only the Python standard library, so
requirements.txt does not change.

How it plugs into app.py:
  * app.py calls  miniapp.push_otp(...)  for every OTP the SMS listener sees.
  * app.py calls  miniapp.start(...)     once from main().
  * The Mini App page calls  /api/feed   every few seconds.
  * Every /api/feed call is checked against Telegram's signed initData, so only
    people who open the app from inside Telegram can read the feed.
"""
import hashlib
import hmac
import html
import json
import os
import re
import threading
import time
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, parse_qsl, urlparse

# ------------------------------------------------------------------
# Look & feel (change these two lines to rename the app)
# ------------------------------------------------------------------
APP_TITLE = "SUPPORT PALESTINE OTP"
APP_SUBTITLE = "Stay Connected with Palestine"

FEED_LIMIT = 200             # OTPs kept in memory
PAGE_SIZE = 50               # OTPs sent to the app per refresh
INITDATA_MAX_AGE = 3 * 24 * 3600
MIN_SEARCH_DIGITS = 4

_feed = deque(maxlen=FEED_LIMIT)
_seen = set()
_lock = threading.Lock()
# Same bot token as the bot project (used to verify Telegram initData and to
# authorise OTPs pushed by the bot). Can also be set as env var BOT_TOKEN.
BOT_TOKEN = os.environ.get("BOT_TOKEN") or "8739706244:AAHdBtPGkYiwczUuly-7GwQIe2wjX9ubALo"

_state = {"today": 0, "channel": ""}
_cfg = {
    "token": "",
    "today": lambda: _state["today"],
    "channel": lambda: _state["channel"],
    # Set env MINIAPP_DEV=1 to open the page in a normal browser for testing.
    "dev": os.environ.get("MINIAPP_DEV") == "1",
}


# ------------------------------------------------------------------
# Feed storage
# ------------------------------------------------------------------
def _parse_ts(value):
    try:
        v = float(value)
        if v > 1e12:
            v /= 1000.0
        if 1.5e9 < v < 4e9:
            return v
    except (TypeError, ValueError):
        pass
    return None


def push_otp(service, number, c_code, country, flag, message, code, raw_ts=None):
    """Add one OTP to the live feed (duplicates are ignored)."""
    digits = re.sub(r"\D", "", str(number or ""))
    if not digits:
        return
    message = str(message or "")
    sig = hashlib.md5(f"{digits}|{message}".encode("utf-8", "ignore")).hexdigest()[:14]
    code = "" if str(code or "") == "COPY" else str(code or "")
    item = {
        "id": sig,
        "service": str(service or "Other"),
        "number": digits,
        "cc": re.sub(r"\D", "", str(c_code or "")),
        "country": str(country or "Unknown"),
        "flag": str(flag or ""),
        "code": code,
        "message": message[:300],
        "ts": _parse_ts(raw_ts) or time.time(),
    }
    with _lock:
        if sig in _seen:
            return
        _seen.add(sig)
        _feed.appendleft(item)
        if len(_seen) > FEED_LIMIT * 5:
            _seen.clear()
            _seen.update(i["id"] for i in _feed)


def _mask(digits, cc):
    keep = len(cc) if cc and digits.startswith(cc) else 2
    tail = 3
    if len(digits) <= keep + tail:
        return digits[:1] + "*" * (len(digits) - 1)
    return digits[:keep] + "*" * (len(digits) - keep - tail) + digits[-tail:]


def _public(item):
    return {
        "id": item["id"],
        "service": item["service"],
        "number": _mask(item["number"], item["cc"]),
        "country": item["country"],
        "flag": item["flag"],
        "code": item["code"],
        "message": item["message"],
        "ts": int(item["ts"]),
    }


# ------------------------------------------------------------------
# Telegram initData check
# https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
# ------------------------------------------------------------------
def _check_init_data(init_data):
    """Returns the Telegram user dict if the data is genuine, else None."""
    if _cfg["dev"]:
        return {}
    try:
        pairs = dict(parse_qsl(init_data or "", keep_blank_values=True))
        received = pairs.pop("hash", None)
        if not received:
            return None
        check_string = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
        secret = hmac.new(b"WebAppData", _cfg["token"].encode(), hashlib.sha256).digest()
        expected = hmac.new(secret, check_string.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, received):
            return None
        if time.time() - int(pairs.get("auth_date", "0")) > INITDATA_MAX_AGE:
            return None
        return json.loads(pairs.get("user", "{}"))
    except Exception:
        return None


# ------------------------------------------------------------------
# HTTP server
# ------------------------------------------------------------------
class _Handler(BaseHTTPRequestHandler):
    server_version = "Codebox"

    def log_message(self, *args):
        pass

    def _send(self, status, body, ctype):
        data = body if isinstance(body, bytes) else body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(data)

    def _json(self, status, obj):
        self._send(status, json.dumps(obj, ensure_ascii=False), "application/json; charset=utf-8")

    def do_POST(self):
        url = urlparse(self.path)
        if url.path != "/api/push":
            return self._send(404, "Not found", "text/plain")
        secret = hashlib.sha256(_cfg["token"].encode()).hexdigest()
        if not hmac.compare_digest(self.headers.get("X-Push-Secret", ""), secret):
            return self._json(401, {"error": "bad secret"})
        try:
            length = min(int(self.headers.get("Content-Length", "0")), 20000)
            d = json.loads(self.rfile.read(length) or b"{}")
            push_otp(d.get("service"), d.get("number"), d.get("cc"), d.get("country"),
                     d.get("flag"), d.get("message"), d.get("code"), d.get("ts"))
            if str(d.get("today", "")).isdigit():
                _state["today"] = int(d["today"])
            _state["channel"] = str(d.get("channel") or "")
        except Exception:
            return self._json(400, {"error": "bad request"})
        self._json(200, {"ok": True})

    def do_GET(self):
        url = urlparse(self.path)
        if url.path in ("/", "/index.html"):
            self._send(200, PAGE, "text/html; charset=utf-8")
        elif url.path == "/health":
            self._send(200, "ok", "text/plain")
        elif url.path == "/api/feed":
            self._feed_api(url)
        else:
            self._send(404, "Not found", "text/plain")

    def _feed_api(self, url):
        if _check_init_data(self.headers.get("X-Init-Data", "")) is None:
            return self._json(401, {"error": "Please open this app from the bot inside Telegram."})

        q = re.sub(r"\D", "", parse_qs(url.query).get("q", [""])[0])
        if q and len(q) < MIN_SEARCH_DIGITS:
            return self._json(400, {"error": f"Enter at least {MIN_SEARCH_DIGITS} digits of the number."})

        with _lock:
            items = list(_feed)
        if q:
            items = [i for i in items if q in i["number"]]

        try:
            today = int(_cfg["today"]())
        except Exception:
            today = 0
        try:
            channel = str(_cfg["channel"]() or "")
        except Exception:
            channel = ""

        self._json(200, {
            "today": today,
            "channel": channel if channel.startswith("https://t.me/") else "",
            "items": [_public(i) for i in items[:PAGE_SIZE]],
        })


def start(token, port=8080, today_fn=None, channel_fn=None):
    """Start the web server in a background thread."""
    _cfg["token"] = token
    if today_fn:
        _cfg["today"] = today_fn
    if channel_fn:
        _cfg["channel"] = channel_fn
    server = ThreadingHTTPServer(("0.0.0.0", int(port)), _Handler)
    server.daemon_threads = True
    threading.Thread(target=server.serve_forever, daemon=True).start()
    print(f"[miniapp] Codebox listening on port {port}")
    return server


# ------------------------------------------------------------------
# The page
# ------------------------------------------------------------------
_PAGE_TEMPLATE = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover, user-scalable=no">
<meta name="color-scheme" content="dark">
<title>__TITLE__</title>
<script src="https://telegram.org/js/telegram-web-app.js"></script>
<style>
:root{
  --bg:#080c0a; --surface:#0d1410; --surface2:#111a15; --line:#1b2a21;
  --text:#e9f0ea; --muted:#7f8d84; --green:#22b35e; --green-d:#168a49;
  --red:#e5334a; --tg:#2aabee;
}
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
html,body{background:var(--bg);color:var(--text);
  font:15px/1.4 Inter,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif}
body{min-height:100vh;padding-bottom:calc(88px + env(safe-area-inset-bottom,0px))}
.flag{display:flex;height:4px;width:100%}
.flag i{display:block;height:100%}
.flag i:nth-child(1){flex:1;background:#000}
.flag i:nth-child(2){flex:1;background:#fff}
.flag i:nth-child(3){flex:1;background:#13a24f}
.flag i:nth-child(4){flex:1;background:#e4312b}
main{max-width:520px;margin:0 auto;padding:22px 16px 0}
header{text-align:center;margin-bottom:20px}
h1{font-size:20px;font-weight:800;letter-spacing:.02em}
header p{font-size:12px;color:var(--muted);margin-top:3px}

.panel{background:var(--surface);border:1px solid var(--line);border-radius:16px;padding:14px}
.field{display:flex;align-items:center;gap:10px;background:var(--surface2);
  border:1px solid var(--line);border-radius:12px;padding:0 14px;height:50px}
.field:focus-within{border-color:var(--green)}
.field svg{flex:none;width:18px;height:18px;stroke:var(--muted)}
.field input{flex:1;min-width:0;background:none;border:0;outline:0;color:var(--text);font:inherit;font-size:16px}
.field input::placeholder{color:#5d6a62}
.primary{display:block;width:100%;margin-top:12px;height:50px;border:0;border-radius:12px;cursor:pointer;
  background:linear-gradient(180deg,#27c068,var(--green-d));color:#fff;font:inherit;
  font-size:15px;font-weight:800;letter-spacing:.06em}
.primary:active{transform:scale(.985)}
.primary:focus-visible,.copy:focus-visible,#tgfab:focus-visible{outline:2px solid #fff;outline-offset:2px}
.hint{display:flex;align-items:center;gap:8px;margin-top:12px;background:var(--surface2);
  border:1px solid var(--line);border-radius:10px;padding:9px 12px;font-size:12.5px;color:var(--muted)}
.hint .dot{flex:none;width:6px;height:6px;border-radius:50%;background:var(--muted)}
.hint.err{color:#ff8a98}.hint.err .dot{background:var(--red)}
.hint.ok{color:#8be0ae}.hint.ok .dot{background:var(--green)}

.feedhead{display:flex;justify-content:space-between;align-items:center;margin:22px 2px 10px;
  font-size:12px;font-weight:800;letter-spacing:.05em}
.live{display:flex;align-items:center;gap:8px;color:#ff6b7d}
.live i{width:8px;height:8px;border-radius:50%;background:var(--red);animation:pulse 1.6s ease-in-out infinite}
#count{color:var(--muted);font-weight:500;letter-spacing:0}

.card{background:var(--surface);border:1px solid var(--line);border-radius:16px;padding:14px;margin-bottom:12px}
.card.latest{border-color:#1d7a47;box-shadow:0 0 0 1px rgba(34,179,94,.15) inset,0 0 22px rgba(34,179,94,.08)}
.top{display:flex;justify-content:space-between;align-items:flex-start;gap:10px}
.brand{display:flex;align-items:center;gap:8px;flex-wrap:wrap;font-size:10.5px;font-weight:800;
  letter-spacing:.04em;color:var(--green)}
.badge{background:#103d25;color:#6ee3a0;border:1px solid #1d7a47;border-radius:6px;padding:1px 6px;
  font-size:9.5px;letter-spacing:.06em}
.meta{text-align:right;font-size:10.5px;line-height:1.35}
.meta .time{display:block;color:var(--muted)}
.meta .svc{display:block;color:var(--green);font-weight:800;text-transform:uppercase;letter-spacing:.03em}
.num{margin-top:10px;font-size:14px;font-weight:700}
.cty{font-size:12px;color:var(--muted);margin-top:1px}
.code{text-align:center;font-size:34px;font-weight:800;letter-spacing:.14em;margin:12px 0 10px;
  font-variant-numeric:tabular-nums;word-break:break-all}
.code.none{color:var(--muted);letter-spacing:0}
.msg{background:#0a110d;border:1px solid var(--line);border-radius:8px;padding:8px 10px;
  font:11.5px/1.45 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;color:#a9b8ae;word-break:break-word}
.copy{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;margin-top:10px;height:42px;
  border-radius:10px;border:1px solid var(--line);background:var(--surface2);color:var(--text);
  font:inherit;font-size:13px;font-weight:700;cursor:pointer}
.copy svg{width:16px;height:16px;stroke:currentColor}
.copy:active{background:#16231c}
.copy.done{border-color:var(--green);color:#8be0ae}
.copy:disabled{opacity:.45;cursor:default}

.state{text-align:center;color:var(--muted);padding:36px 12px;font-size:13px}
.state p{margin-top:12px}
.spin{width:26px;height:26px;margin:0 auto;border-radius:50%;border:3px solid #1c2a22;
  border-top-color:var(--green);animation:spin .8s linear infinite}

#tgfab{position:fixed;right:16px;bottom:calc(18px + env(safe-area-inset-bottom,0px));width:54px;height:54px;
  border:0;border-radius:50%;background:var(--tg);display:flex;align-items:center;justify-content:center;
  box-shadow:0 6px 18px rgba(0,0,0,.5);cursor:pointer}
#tgfab[hidden]{display:none}
#tgfab svg{width:26px;height:26px;fill:#fff}

@keyframes spin{to{transform:rotate(360deg)}}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.35}}
@media (prefers-reduced-motion:reduce){.live i,.spin{animation:none}}
</style>
</head>
<body>
<div class="flag"><i></i><i></i><i></i><i></i></div>
<main>
  <header><h1>__TITLE__</h1><p>__SUBTITLE__</p></header>

  <section class="panel">
    <label class="field">
      <svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg>
      <input id="num" type="tel" inputmode="tel" autocomplete="off" placeholder="Enter phone number" aria-label="Phone number">
    </label>
    <button id="go" class="primary" type="button">GET CODES</button>
    <div id="hintbox" class="hint"><span class="dot"></span><span id="hint">Enter a number and search...</span></div>
  </section>

  <div class="feedhead"><span class="live"><i></i>LIVE CODES FEED</span><span id="count">Loading...</span></div>
  <div id="feed"><div class="state"><div class="spin"></div><p>Loading live codes...</p></div></div>
</main>

<button id="tgfab" type="button" hidden aria-label="Open channel">
  <svg viewBox="0 0 24 24"><path d="M21.9 4.3 18.6 20c-.2 1-.9 1.3-1.8.8l-5-3.7-2.4 2.3c-.3.3-.5.5-1 .5l.4-5.1 9.3-8.4c.4-.4-.1-.6-.6-.2L6.1 13.4 1.2 11.9c-1-.3-1-1 .2-1.5L20.5 3.1c.9-.3 1.7.2 1.4 1.2z"/></svg>
</button>

<script>
(function(){
  var tg = window.Telegram && window.Telegram.WebApp;
  if (tg) {
    tg.ready(); tg.expand();
    try { tg.setHeaderColor('#080c0a'); tg.setBackgroundColor('#080c0a'); } catch(e) {}
  }
  var MIN_DIGITS = 4;
  var BRAND = document.querySelector('h1').textContent;
  var feedEl = document.getElementById('feed');
  var countEl = document.getElementById('count');
  var hintEl = document.getElementById('hint');
  var hintBox = document.getElementById('hintbox');
  var input = document.getElementById('num');
  var fab = document.getElementById('tgfab');
  var query = '', lastSig = '', busy = false, channel = '';

  function el(tag, cls, txt){
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (txt !== undefined) n.textContent = txt;
    return n;
  }
  function setHint(text, kind){
    hintEl.textContent = text;
    hintBox.className = 'hint' + (kind ? ' ' + kind : '');
  }
  function fmtTime(ts){
    try { return new Date(ts * 1000).toLocaleTimeString([], {hour:'numeric', minute:'2-digit'}); }
    catch(e) { return ''; }
  }
  function haptic(kind){
    try { tg && tg.HapticFeedback && tg.HapticFeedback.notificationOccurred(kind); } catch(e) {}
  }

  function copyText(text, btn){
    function done(){
      var old = btn.lastChild.textContent;
      btn.classList.add('done'); btn.lastChild.textContent = 'Copied';
      haptic('success');
      setTimeout(function(){ btn.classList.remove('done'); btn.lastChild.textContent = old; }, 1300);
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(done, function(){ fallback(); });
    } else { fallback(); }
    function fallback(){
      var ta = document.createElement('textarea');
      ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.focus(); ta.select();
      try { document.execCommand('copy'); done(); } catch(e) {}
      document.body.removeChild(ta);
    }
  }

  function card(it, latest){
    var c = el('article', 'card' + (latest ? ' latest' : ''));
    var top = el('div', 'top');
    var brand = el('div', 'brand', BRAND);
    if (latest) brand.appendChild(el('span', 'badge', 'LATEST'));
    var meta = el('div', 'meta');
    meta.appendChild(el('span', 'time', fmtTime(it.ts)));
    meta.appendChild(el('span', 'svc', it.service));
    top.appendChild(brand); top.appendChild(meta);
    c.appendChild(top);

    c.appendChild(el('div', 'num', 'Number: ' + it.number));
    c.appendChild(el('div', 'cty', 'Country: ' + (it.flag ? it.flag + ' ' : '') + it.country));

    var hasCode = !!it.code;
    c.appendChild(el('div', 'code' + (hasCode ? '' : ' none'), hasCode ? it.code : 'No code found'));
    if (it.message) c.appendChild(el('div', 'msg', it.message));

    var btn = el('button', 'copy');
    btn.type = 'button';
    btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>';
    btn.appendChild(document.createTextNode('Copy Code'));
    if (hasCode) {
      btn.addEventListener('click', function(){ copyText(it.code.replace(/[\s-]/g, ''), btn); });
    } else { btn.disabled = true; }
    c.appendChild(btn);
    return c;
  }

  function showState(spin, text){
    feedEl.textContent = '';
    var s = el('div', 'state');
    if (spin) s.appendChild(el('div', 'spin'));
    s.appendChild(el('p', '', text));
    feedEl.appendChild(s);
  }

  function render(d, force){
    countEl.textContent = (d.today || 0) + ' codes today';
    if (d.channel && d.channel !== channel) { channel = d.channel; fab.hidden = false; }
    var sig = query + '|' + d.items.map(function(i){ return i.id; }).join(',');
    if (sig === lastSig && !force) return;
    lastSig = sig;

    if (!d.items.length) {
      showState(false, query
        ? 'No codes yet for this number. Request the OTP, then press Get Codes again.'
        : 'No codes yet. New codes appear here as soon as they arrive.');
    } else {
      feedEl.textContent = '';
      d.items.forEach(function(it, idx){ feedEl.appendChild(card(it, idx === 0 && !query)); });
    }
    if (query) {
      setHint(d.items.length ? ('Showing codes for number containing ' + query) : ('No codes yet for ' + query), d.items.length ? 'ok' : '');
    } else {
      setHint('Showing all live codes. Enter a number to filter.', '');
    }
  }

  function load(force){
    if (busy) return;
    busy = true;
    fetch('/api/feed?q=' + encodeURIComponent(query), {
      headers: {'X-Init-Data': tg ? tg.initData : ''}, cache: 'no-store'
    }).then(function(r){
      return r.json().then(function(d){ return {ok: r.ok, d: d}; });
    }).then(function(res){
      if (!res.ok) {
        setHint(res.d.error || 'Something went wrong.', 'err');
        if (!lastSig) showState(false, res.d.error || 'Something went wrong.');
        return;
      }
      render(res.d, force);
    }).catch(function(){
      setHint('Connection lost. Retrying...', 'err');
    }).then(function(){ busy = false; });
  }

  function search(){
    var digits = input.value.replace(/\D/g, '');
    if (digits && digits.length < MIN_DIGITS) {
      setHint('Enter at least ' + MIN_DIGITS + ' digits of the number.', 'err');
      haptic('error');
      return;
    }
    query = digits; lastSig = '';
    setHint('Searching...', '');
    load(true);
    input.blur();
  }

  document.getElementById('go').addEventListener('click', search);
  input.addEventListener('keydown', function(e){ if (e.key === 'Enter') search(); });
  input.addEventListener('input', function(){
    if (!input.value.trim() && query) { query = ''; lastSig = ''; load(true); }
  });
  fab.addEventListener('click', function(){
    if (!channel) return;
    if (tg && tg.openTelegramLink) tg.openTelegramLink(channel); else window.open(channel, '_blank');
  });

  load(true);
  setInterval(function(){ if (!document.hidden) load(false); }, 4000);
})();
</script>
</body>
</html>
"""

PAGE = (_PAGE_TEMPLATE
        .replace("__TITLE__", html.escape(APP_TITLE))
        .replace("__SUBTITLE__", html.escape(APP_SUBTITLE)))


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8080"))
    if os.environ.get("MINIAPP_DEV") == "1":
        # Local preview:  MINIAPP_DEV=1 python miniapp.py   then open http://localhost:8080
        _cfg["dev"] = True
        push_otp("Facebook", "4915123456464", "49", "Germany", "🇩🇪", "138790 is your password reset code for Facebook", "138790")
        push_otp("Instagram", "33612345599", "33", "France", "🇫🇷", "638 068 is your Instagram code. Dont share it", "638 068")
        _state["today"] = 196
    start(BOT_TOKEN, port)
    while True:
        time.sleep(3600)
